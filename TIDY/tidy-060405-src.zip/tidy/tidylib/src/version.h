/* version information

  (c) 2006 (W3C) MIT, ERCIM, Keio University
  See tidy.h for the copyright notice.

  CVS Info :

    $Author: arnaud02 $ 
    $Date: 2006/02/14 13:44:47 $ 
    $Revision: 1.3 $ 

*/

static const char release_date[] = "14 February 2006";
